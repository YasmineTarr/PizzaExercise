import UIKit

class crust {
   var crusttype1 = "stuffed"
   var crusttype2 = "unstuffed"
   
}

let crusttype = crust()
print( "I would like to select the \(crusttype.crusttype1) crust")

class topping {
   var topping1 = "pepperoni"
   var topping2 = "sausage"
   
}

let toppings = topping()
print( "I would like to select the \(toppings.topping1) for my topping")
